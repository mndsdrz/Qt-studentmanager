#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QRadioButton>
#include "studentform.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QMessageBox>
#include<manger.h>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
/*
QObject 是所有Qt对象的基类。
QObject 是Qt模块的核心。它的最主要特征是关于对象间无缝通信的机制：信号与槽。
使用connect()建立信号到槽的连接，使用disconnect()销毁连接，使用blockSignals()暂时阻塞信号以避免无限通知循环，
使用connectNotify()和disconnectNotify()追踪连接。
QObject 以对象树的形式组织起来。当为一个对象创建子对象时，子对象会自动地添加到父对象的children()列表中。
父对象拥有子对象的所有权，比如父对象可以在自己的析构函数中删除它的孩子对象。
使用findChild()或findChildren()通过名字和类型查询孩子对象。
*/

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_LoginButton_clicked();
    void show2();
   // void open();
    void on_remitButton_clicked();

signals:
    void sendData(QString);
private:
    Ui::MainWindow *ui;
    studentForm *f;
    manger *m;
};

#endif // MAINWINDOW_H
