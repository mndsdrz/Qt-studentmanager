#include "mainwindow.h"
#include <QApplication>
#include <QTextCodec>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    /*QApplication代表一个程序，Window代表一个窗口。一个程序可以有多个窗口。
    argc和argv是命令行传进去的参数。比如linux里输入一个命令
    cp file.c file1.c
    那么argc=3 argv就是上面那行字符串数组。
    因为图形编程有时也需要从命令行传递参数给程序，所以才会有argc和argv。
    a.exec()就是程序进程开始运行。*/
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("GBK"));
   // QTextCodec::setCodecForCStrings(QTextCodec::codecForName("GBK"));
 //   QTextCodec::setCodecForTr(QTextCodec::codecForName("GBK"));

  //  QTextCodec::setCodecForTr(QTextCodec::codecForName("GBK"));
 //   QTextCodec::setCodecForCStrings(QTextCodec::codecForName("GBK"));
 //   QTextCodec::setCodecForCStrings(QTextCodec::codecForName("GBK"));


    MainWindow w;
    w.show();

    return a.exec();
}
