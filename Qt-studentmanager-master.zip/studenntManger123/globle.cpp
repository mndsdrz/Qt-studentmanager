#include "globle.h"
int num01;
QString str = "test";
QString username_qj = "";
 QString password_qj = "";
QVariantList list_all_student;
QString sqluser="root";
QString sqlpass="123456789";
QVariantList list_all_dormstudent;
