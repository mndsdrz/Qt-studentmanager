#include "student.h"

student::student(QObject *parent) : QObject(parent)
{


}
